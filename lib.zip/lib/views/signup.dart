import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stockpulse/common/route/app_routes.dart';
import 'package:stockpulse/common/widgets/custome_button.dart';
import 'package:stockpulse/common/widgets/custome_textfield.dart';
import 'package:stockpulse/common/widgets/custome_textbutton.dart';
import 'package:stockpulse/controllers/signupController.dart';
import 'package:stockpulse/utils/app_constants.dart';

class SignupView extends StatefulWidget {
  const SignupView({super.key});

  @override
  State<SignupView> createState() => _SignupViewState();
}

class _SignupViewState extends State<SignupView> {
  static const background = Color(0xFF101116);
  static const surface = Color(0xFF191B23);
  static const field = Color(0xFF1D202A);
  static const primary = Color(0xFF665BFF);
  static const text = Color(0xFFF5F5FA);
  static const muted = Color(0xFF8E91A4);
  static const divider = Color(0xFF2A2D37);
  static const success = Color(0xFF00D9A5);

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<SignupController>();

    return Scaffold(
      backgroundColor: background,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = (constraints.maxWidth - 32).clamp(0.0, 440.0);

            return Center(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: SizedBox(
                  width: width,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const _BrandMark(),
                      const SizedBox(height: 18),
                      const Text(
                        AppConstants.signupTitle,
                        style: TextStyle(
                          color: text,
                          fontSize: 21,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const SizedBox(
                        width: 270,
                        child: Text(
                          AppConstants.signupSubtitle,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: muted,
                            fontSize: 11,
                            height: 1.35,
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      _SignupPanel(controller: controller),
                      const SizedBox(height: 13),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            AppConstants.signupSignIn,
                            style: TextStyle(color: muted, fontSize: 11),
                          ),
                          CustomTextButton(
                            text: AppConstants.loginButton,
                            onPressed: () => Get.toNamed(Routes.register),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _BrandMark extends StatelessWidget {
  const _BrandMark();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 54,
      height: 54,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF1D1B35),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Image.asset(AppConstants.splashImage, fit: BoxFit.contain),
    );
  }
}

class _SignupPanel extends StatelessWidget {
  const _SignupPanel({required this.controller});

  final SignupController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 15, 16, 14),
      decoration: BoxDecoration(
        color: _SignupViewState.surface,
        borderRadius: BorderRadius.circular(13),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const _FieldLabel(AppConstants.nameLabel),
          const SizedBox(height: 7),
          CustomTextField(
            controller: controller.nameController,
            hintText: AppConstants.nameHint,
            prefixIcon: const Icon(
              Icons.person_outline,
              color: _SignupViewState.muted,
              size: 16,
            ),
            keyboardType: TextInputType.text,
            autofillHints: const [AutofillHints.name],
            textInputAction: TextInputAction.next,
          ),
          const _FieldLabel(AppConstants.loginEmailLabel),
          CustomTextField(
            controller: controller.emailController,
            hintText: AppConstants.loginEmailHint,
            prefixIcon: const Icon(
              Icons.mail_outline,
              color: _SignupViewState.muted,
              size: 16,
            ),
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            textInputAction: TextInputAction.next,
          ),
          _FieldLabel(AppConstants.loginPasswordLabel),
          Obx(
            () => CustomTextField(
              controller: controller.passwordController,
              hintText: 'Enter your password',
              obscureText: controller.obscurePassword.value,
              prefixIcon: const Icon(
                Icons.lock_outline,
                color: _SignupViewState.muted,
                size: 16,
              ),
              suffixIcon: IconButton(
                onPressed: controller.togglePassword,
                padding: EdgeInsets.zero,
                icon: Icon(
                  controller.obscurePassword.value
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  color: _SignupViewState.muted,
                  size: 16,
                ),
              ),
              autofillHints: const [AutofillHints.password],
              textInputAction: TextInputAction.done,
            ),
          ),
          const SizedBox(height: 9),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () {
                  Get.toNamed(Routes.forgotPassword);
                },
                child: Text(
                  AppConstants.loginForgotPassword,
                  style: TextStyle(
                    color: _SignupViewState.text,
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Obx(
            () => AppButton(
              text: 'Sign Up  >',
              onPressed: controller.signup,
              isLoading: controller.isLoading.value,
              backgroundColor: _SignupViewState.primary,
              foregroundColor: Colors.white,
              borderRadius: 8,
              height: 38,
            ),
          ),
          const SizedBox(height: 13),
          const _DividerLabel(),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  padding: const EdgeInsets.all(7),
                  child: Image.asset(
                    AppConstants.googleLogo,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              if (Platform.isIOS) ...[
                Expanded(
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(7),
                    child: Image.asset(
                      AppConstants.appleLogo,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: _SocialButton(
                  label: 'Mobile OTP',
                  icon: Icons.phone_iphone_outlined,
                  color: _SignupViewState.success,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsGeometry.only(top: 7, bottom: 7),
      child: Text(
        label,
        style: const TextStyle(
          color: _SignupViewState.text,
          fontSize: 9,
          fontWeight: FontWeight.w700,
          letterSpacing: .2,
        ),
      ),
    );
  }
}

class _DividerLabel extends StatelessWidget {
  const _DividerLabel();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(child: Divider(color: _SignupViewState.divider)),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 9),
          child: Text(
            'OR CONTINUE WITH',
            style: TextStyle(color: _SignupViewState.muted, fontSize: 8),
          ),
        ),
        const Expanded(child: Divider(color: _SignupViewState.divider)),
      ],
    );
  }
}

class _SocialButton extends StatelessWidget {
  const _SocialButton({
    required this.label,
    required this.icon,
    required this.color,
  });

  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      child: OutlinedButton.icon(
        onPressed: () => Get.toNamed(Routes.phoneDetails),
        icon: Icon(icon, color: color, size: 17),
        label: Text(
          label,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: _SignupViewState.text, fontSize: 10),
        ),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          side: const BorderSide(color: _SignupViewState.divider),
          backgroundColor: _SignupViewState.field,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
    );
  }
}
