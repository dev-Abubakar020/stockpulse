import 'package:flutter/material.dart';

class PhoneDetailScreen extends StatefulWidget {
  const PhoneDetailScreen({super.key});

  @override
  State<PhoneDetailScreen> createState() => _PhoneDetailScreenState();
}

class _PhoneDetailScreenState extends State<PhoneDetailScreen> {
  final phoneController = TextEditingController();

  @override
  void dispose() {
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF101116),
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: SizedBox(
              width: 320,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.maybePop(context),
                        icon: const Icon(
                          Icons.chevron_left,
                          color: Color(0xFF8E91A4),
                        ),
                      ),
                      const Spacer(),
                      const Text(
                        'PHONE VERIFICATION',
                        style: TextStyle(
                          color: Color(0xFF8E91A4),
                          fontSize: 8,
                          letterSpacing: .4,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 25),
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF201D3D),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: const Icon(
                      Icons.phone_android,
                      color: Color(0xFF665BFF),
                      size: 25,
                    ),
                  ),
                  const SizedBox(height: 15),
                  const Text(
                    'Enter your phone number',
                    style: TextStyle(
                      color: Color(0xFFF5F5FA),
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'We will send a secure verification code\nto confirm your identity.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF8E91A4),
                      fontSize: 9,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 21),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF191B23),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFF2A2D37)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'PHONE NUMBER',
                          style: TextStyle(
                            color: Color(0xFFF5F5FA),
                            fontSize: 7,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 7),
                        TextField(
                          controller: phoneController,
                          keyboardType: TextInputType.phone,
                          style: const TextStyle(
                            color: Color(0xFFF5F5FA),
                            fontSize: 11,
                          ),
                          decoration: InputDecoration(
                            hintText: '(300) 123-4567',
                            hintStyle: const TextStyle(
                              color: Color(0xFF8E91A4),
                              fontSize: 10,
                            ),
                            prefixIcon: const Icon(
                              Icons.phone_outlined,
                              color: Color(0xFF8E91A4),
                              size: 15,
                            ),
                            filled: true,
                            fillColor: const Color(0xFF1D202A),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(7),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 8,
                            ),
                          ),
                        ),
                        const SizedBox(height: 13),
                        SizedBox(
                          height: 36,
                          child: ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF665BFF),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: const Text(
                              'Continue  >',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Your number is encrypted and never shared.',
                    style: TextStyle(color: Color(0xFF8E91A4), fontSize: 8),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
