import 'package:flutter/material.dart';
import 'package:stockpulse/common/widgets/custome_textfield.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  static const background = Color(0xFF101116);
  static const surface = Color(0xFF191B23);
  static const field = Color(0xFF1D202A);
  static const primary = Color(0xFF665BFF);
  static const text = Color(0xFFF5F5FA);
  static const muted = Color(0xFF8E91A4);
  static const divider = Color(0xFF2A2D37);
  static const success = Color(0xFF00D9A5);

  final phoneController = TextEditingController();

  @override
  void dispose() {
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _RecoveryScaffold(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _TopBar(),
          const SizedBox(height: 30),
          const _RecoveryIcon(icon: Icons.shield_outlined),
          const SizedBox(height: 15),
          const _Eyebrow('ACCOUNT RECOVERY'),
          const SizedBox(height: 7),
          const Text(
            'Forgot Password?',
            style: TextStyle(
              color: text,
              fontSize: 18,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'Enter your verified email address to receive a\nsecure one-time authentication code.',
            textAlign: TextAlign.center,
            style: TextStyle(color: muted, fontSize: 9, height: 1.35),
          ),
          const SizedBox(height: 20),
          _Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const _Label('Email Address'),
                const SizedBox(height: 7),
                CustomTextField(
                  controller: phoneController,
                  hintText: 'Enter your Email Address',
                ),
                const SizedBox(height: 13),
                _PrimaryButton(
                  label: 'Send Verification Code  >',
                  onPressed: () {},
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.lock_outline, color: success, size: 11),
              SizedBox(width: 5),
              Text(
                '256-BIT ENCRYPTED RECOVERY • INSTANT SMS DELIVERY',
                style: TextStyle(color: muted, fontSize: 7, letterSpacing: .2),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text.rich(
            TextSpan(
              text: 'Remember your password? ',
              style: TextStyle(color: muted, fontSize: 9),
              children: [
                TextSpan(
                  text: 'Sign In',
                  style: TextStyle(color: primary, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RecoveryScaffold extends StatelessWidget {
  const _RecoveryScaffold({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _ForgotPasswordScreenState.background,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: SizedBox(width: 320, child: child),
          ),
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _IconButton(
          icon: Icons.chevron_left,
          onPressed: () => Navigator.maybePop(context),
        ),
        const Spacer(),
        const _StatusPill(
          label: 'APIX VAULT V3.4',
          color: _ForgotPasswordScreenState.success,
        ),
      ],
    );
  }
}

class _RecoveryIcon extends StatelessWidget {
  const _RecoveryIcon({required this.icon});

  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: const Color(0xFF201D3D),
        borderRadius: BorderRadius.circular(11),
        boxShadow: const [BoxShadow(color: Color(0x553B31A1), blurRadius: 12)],
      ),
      child: Icon(icon, color: _ForgotPasswordScreenState.primary, size: 24),
    );
  }
}

class _Eyebrow extends StatelessWidget {
  const _Eyebrow(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0x332A20A6),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: _ForgotPasswordScreenState.primary,
          fontSize: 7,
        ),
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  const _Panel({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _ForgotPasswordScreenState.surface,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _ForgotPasswordScreenState.divider),
      ),
      child: child,
    );
  }
}

class _Label extends StatelessWidget {
  const _Label(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: const TextStyle(
        color: _ForgotPasswordScreenState.text,
        fontSize: 7,
        fontWeight: FontWeight.w700,
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({required this.label, required this.onPressed});

  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 36,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: _ForgotPasswordScreenState.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Text(
          label,
          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}

class _IconButton extends StatelessWidget {
  const _IconButton({required this.icon, required this.onPressed});

  final IconData icon;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onPressed,
      icon: Icon(icon, color: _ForgotPasswordScreenState.muted, size: 16),
      style: IconButton.styleFrom(
        backgroundColor: _ForgotPasswordScreenState.field,
        minimumSize: const Size(25, 25),
        padding: EdgeInsets.zero,
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: _ForgotPasswordScreenState.field,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 7,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
