import 'package:flutter/material.dart';

class OtpVerificationScreen extends StatefulWidget {
  const OtpVerificationScreen({super.key});

  @override
  State<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}

class _OtpVerificationScreenState extends State<OtpVerificationScreen> {
  final codeController = TextEditingController();
  static const primary = Color(0xFF665BFF);
  static const text = Color(0xFFF5F5FA);
  static const muted = Color(0xFF8E91A4);
  static const field = Color(0xFF1D202A);

  @override
  void dispose() {
    codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF101116),
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: SizedBox(
              width: 320,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.maybePop(context),
                        icon: const Icon(Icons.chevron_left, color: muted),
                      ),
                      const Spacer(),
                      const Text(
                        'TWO-FACTOR AUTHENTICATION',
                        style: TextStyle(
                          color: muted,
                          fontSize: 8,
                          letterSpacing: .3,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.info_outline, color: muted, size: 14),
                    ],
                  ),
                  const SizedBox(height: 25),
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFF201D3D),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: const Icon(
                      Icons.verified_user_outlined,
                      color: primary,
                      size: 24,
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'Verify OTP Code',
                    style: TextStyle(
                      color: text,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'We sent a 6-digit verification code to\n+92 •••••••• 4567  Edit',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: muted, fontSize: 9, height: 1.4),
                  ),
                  const SizedBox(height: 18),
                  _OtpBoxes(controller: codeController),
                  const SizedBox(height: 12),
                  const Text(
                    'Resend code in 00:48',
                    style: TextStyle(color: muted, fontSize: 8),
                  ),
                  const SizedBox(height: 19),
                  SizedBox(
                    width: double.infinity,
                    height: 36,
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primary,
                        foregroundColor: Colors.white,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: const Text(
                        'Verify & Reset Password  >',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const _Keypad(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _OtpBoxes extends StatelessWidget {
  const _OtpBoxes({required this.controller});

  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 38,
      child: TextField(
        controller: controller,
        autofocus: true,
        maxLength: 6,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: _OtpVerificationScreenState.text,
          fontSize: 16,
          fontWeight: FontWeight.w700,
          letterSpacing: 12,
        ),
        decoration: const InputDecoration(
          counterText: '',
          filled: true,
          fillColor: _OtpVerificationScreenState.field,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(7)),
            borderSide: BorderSide.none,
          ),
          contentPadding: EdgeInsets.symmetric(vertical: 8),
        ),
      ),
    );
  }
}

class _Keypad extends StatelessWidget {
  const _Keypad();

  @override
  Widget build(BuildContext context) {
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '•', '0', '⌫'];
    return GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 5,
      crossAxisSpacing: 5,
      childAspectRatio: 2.15,
      children: keys
          .map(
            (key) => Container(
              decoration: BoxDecoration(
                color: _OtpVerificationScreenState.field,
                borderRadius: BorderRadius.circular(6),
              ),
              alignment: Alignment.center,
              child: Text(
                key,
                style: const TextStyle(
                  color: _OtpVerificationScreenState.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}
