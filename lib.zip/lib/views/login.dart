import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stockpulse/common/route/app_routes.dart';
import 'package:stockpulse/common/widgets/custome_button.dart';
import 'package:stockpulse/common/widgets/custome_textfield.dart';
import 'package:stockpulse/common/widgets/custome_textbutton.dart';
import 'package:stockpulse/controllers/loginController.dart';
import 'package:stockpulse/utils/app_constants.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  static const background = Color(0xFF101116);
  static const surface = Color(0xFF191B23);
  static const field = Color(0xFF1D202A);
  static const primary = Color(0xFF665BFF);
  static const text = Color(0xFFF5F5FA);
  static const muted = Color(0xFF8E91A4);
  static const divider = Color(0xFF2A2D37);
  static const success = Color(0xFF00D9A5);

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<LoginController>();

    return Scaffold(
      backgroundColor: background,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final width = (constraints.maxWidth - 32).clamp(0.0, 440.0);

            return Center(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: SizedBox(
                  width: width,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const _BrandMark(),
                      const SizedBox(height: 18),
                      const Text(
                        AppConstants.loginWelcomeTitle,
                        style: TextStyle(
                          color: text,
                          fontSize: 21,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const SizedBox(
                        width: 270,
                        child: Text(
                          'Enter your credentials to access your secure workspace',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: muted,
                            fontSize: 11,
                            height: 1.35,
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      _LoginPanel(controller: controller),
                      const SizedBox(height: 13),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            AppConstants.loginNoAccount,
                            style: TextStyle(color: muted, fontSize: 11),
                          ),
                          CustomTextButton(
                            text: AppConstants.loginSignUp,
                            onPressed: () => Get.toNamed(Routes.register),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _BrandMark extends StatelessWidget {
  const _BrandMark();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 54,
      height: 54,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF1D1B35),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Image.asset(AppConstants.splashImage, fit: BoxFit.contain),
    );
  }
}

class _LoginPanel extends StatelessWidget {
  const _LoginPanel({required this.controller});

  final LoginController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 15, 16, 14),
      decoration: BoxDecoration(
        color: _LoginScreenState.surface,
        borderRadius: BorderRadius.circular(13),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const _FieldLabel(AppConstants.loginEmailLabel),
          const SizedBox(height: 7),
          CustomTextField(
            controller: controller.emailController,
            hintText: AppConstants.loginEmailHint,
            prefixIcon: const Icon(
              Icons.mail_outline,
              color: _LoginScreenState.muted,
              size: 16,
            ),
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            textInputAction: TextInputAction.next,
          ),
          _FieldLabel(AppConstants.loginPasswordLabel),
          Obx(
            () => CustomTextField(
              controller: controller.passwordController,
              hintText: 'Enter your password',
              obscureText: controller.obscurePassword.value,
              prefixIcon: const Icon(
                Icons.lock_outline,
                color: _LoginScreenState.muted,
                size: 16,
              ),
              suffixIcon: IconButton(
                onPressed: controller.togglePassword,
                padding: EdgeInsets.zero,
                icon: Icon(
                  controller.obscurePassword.value
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  color: _LoginScreenState.muted,
                  size: 16,
                ),
              ),
              autofillHints: const [AutofillHints.password],
              textInputAction: TextInputAction.done,
            ),
          ),
          const SizedBox(height: 9),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              const Text(
                AppConstants.loginForgotPassword,
                style: TextStyle(
                  color: _LoginScreenState.text,
                  fontSize: 9,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Obx(
            () => AppButton(
              text: 'Sign In  >',
              onPressed: controller.login,
              isLoading: controller.isLoading.value,
              backgroundColor: _LoginScreenState.primary,
              foregroundColor: Colors.white,
              borderRadius: 8,
              height: 38,
            ),
          ),
          const SizedBox(height: 13),
          const _DividerLabel(),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  padding: const EdgeInsets.all(7),
                  child: Image.asset(
                    AppConstants.googleLogo,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              if (Platform.isIOS) ...[
                Expanded(
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    padding: const EdgeInsets.all(7),
                    child: Image.asset(
                      AppConstants.appleLogo,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: InkWell(
                  onTap: () {
                    Get.toNamed(Routes.phoneDetails);
                  },
                  child: _SocialButton(
                    label: 'Mobile OTP',
                    icon: Icons.phone_iphone_outlined,
                    color: _LoginScreenState.success,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsGeometry.only(top: 7, bottom: 7),
      child: Text(
        label,
        style: const TextStyle(
          color: _LoginScreenState.text,
          fontSize: 9,
          fontWeight: FontWeight.w700,
          letterSpacing: .2,
        ),
      ),
    );
  }
}

class _DividerLabel extends StatelessWidget {
  const _DividerLabel();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Expanded(child: Divider(color: _LoginScreenState.divider)),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 9),
          child: Text(
            'OR CONTINUE WITH',
            style: TextStyle(color: _LoginScreenState.muted, fontSize: 8),
          ),
        ),
        const Expanded(child: Divider(color: _LoginScreenState.divider)),
      ],
    );
  }
}

class _SocialButton extends StatelessWidget {
  const _SocialButton({
    required this.label,
    required this.icon,
    required this.color,
  });

  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 32,
      child: OutlinedButton.icon(
        onPressed: () {},
        icon: Icon(icon, color: color, size: 17),
        label: Text(
          label,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: _LoginScreenState.text, fontSize: 10),
        ),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          side: const BorderSide(color: _LoginScreenState.divider),
          backgroundColor: _LoginScreenState.field,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
    );
  }
}
