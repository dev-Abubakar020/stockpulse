import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:stockpulse/services/local_storage_service.dart';
import 'package:stockpulse/utils/app_constants.dart';
import 'package:stockpulse/common/route/app_pages.dart';
import 'package:stockpulse/common/route/app_routes.dart';
import 'package:stockpulse/common/bindings/initialBinding.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// stockpulse- Hafiz@12486
Future<void> main() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();
    await Supabase.initialize(
      url: AppConstants.supabaseUrl,
      anonKey: AppConstants.supabaseAnonKey,
    );

    await LocalStorageService.init();
    Get.put(LocalStorageService(), permanent: true);
  } catch (e) {
    debugPrint("Error during initialization: $e");
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppConstants.appName,
      initialBinding: InitialBinding(),
      themeMode: ThemeMode.light,
      initialRoute: Routes.onboarding,
      getPages: AppPages.pages,
    );
  }
}
