import 'package:flutter/material.dart';

/// StockPulse's premium vendor/POS color palette.
class AppColors {
  AppColors._();

  // Brand colors
  static const Color primary = Color(0xFF0F766E); // Deep teal
  static const Color primaryDark = Color(0xFF115E59);
  static const Color secondary = Color(0xFF14263D); // Midnight navy
  static const Color accent = Color(0xFFD5A84B); // Muted gold

  // Background and surfaces
  static const Color background = Color(0xFFF6F8F8);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceMuted = Color(0xFFEEF5F3);
  static const Color cardShadow = Color(0x140F2A35);

  // Text
  static const Color textPrimary = Color(0xFF14263D);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textHint = Color(0xFF94A3B8);
  static const Color textOnPrimary = Color(0xFFFFFFFF);

  // Business and status indicators
  static const Color sales = Color(0xFF0F766E);
  static const Color purchases = Color(0xFF2563EB);
  static const Color profit = Color(0xFF15803D);
  static const Color expense = Color(0xFFDC2626);
  static const Color success = Color(0xFF16A34A);
  static const Color error = Color(0xFFDC2626);
  static const Color warning = Color(0xFFD97706);
  static const Color lowStock = warning;

  // Borders and dividers
  static const Color border = Color(0xFFDDE5E7);
  static const Color divider = Color(0xFFEDF1F2);

  // Dark theme surfaces and text (brand colors remain recognizable)
  static const Color darkBackground = Color(0xFF0B1724);
  static const Color darkSurface = Color(0xFF14263D);
  static const Color darkSurfaceMuted = Color(0xFF1B3449);
  static const Color darkTextPrimary = Color(0xFFF4F8FA);
  static const Color darkTextSecondary = Color(0xFFB3C5D0);
  static const Color darkTextHint = Color(0xFF8EA3B1);
  static const Color darkBorder = Color(0xFF315065);
  static const Color darkDivider = Color(0xFF253E51);
  static const Color darkCardShadow = Color(0x40000000);
  static const Color darkPrimary = Color(0xFF38BDB0);
  static const Color darkError = Color(0xFFFF6B6B);

  // Onboarding
  static const Color onboardingLight = Color(0xFFEAF7F5);
  static const Color onboardingDark = Color(0xFF0D1F22);

  // Primary button / hero treatment
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryDark, primary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
