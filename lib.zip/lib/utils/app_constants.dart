class AppConstants {
  AppConstants._();

  static const String appName = 'StockPulse';
  static const String appVersion = '1.0.0';

  static const String supabaseUrl = 'https://lrfszjtnmsvevmkkiuna.supabase.co';
  static const String supabaseAnonKey =
      'sb_publishable_GRRl45M2HhkvRoLKgT6R1A_Jr04DeT7';
  static const String stagAppName = 'StockPulse';
  static const String splashSlug = 'Initializing Data...';

  static const String googleLogo = 'assets/images/googlelogo.png';
  static const String appleLogo = 'assets/images/applelogo.png';
  static const String phoneLogo = 'assets/images/phonelogo.png';
  static const String splashImage = 'assets/images/splashImage.png';

  static const String loginWelcomeTitle = 'Welcome Back';
  static const String signupTitle = 'Create Account';
  static const String signupSubtitle =
      'Enter your details to register your secure zero-knowledge workspace';
  static const String loginWelcomeSubtitle =
      'Sign in to manage your store, sales, and inventory.';
  static const String loginEmailLabel = 'Email';
  static const String nameLabel = 'Name';
  static const String nameHint = 'Enter your name';
  static const String loginEmailHint = 'Enter your email';
  static const String loginPasswordLabel = 'Password';
  static const String loginPasswordHint = 'Enter your password';
  static const String loginForgotPassword = 'Forgot password?';
  static const String loginButton = 'Sign In';
  static const String loginContinueWith = 'or continue with';
  static const String loginGoogle = 'Google';
  static const String loginPhone = 'Phone';
  static const String loginNoAccount = "Don't have an account?";
  static const String signupSignIn = 'Already have an account?';
  static const String loginSignUp = 'Sign Up >';
}
