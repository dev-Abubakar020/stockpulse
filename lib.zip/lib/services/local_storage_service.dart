import 'package:get_storage/get_storage.dart';

class LocalStorageService {
  final GetStorage _box = GetStorage();
  static const String _firstTimeKey = 'is_first_time';
  // static const String _userNameKey = 'user_name';

  static Future<void> init() async {
    await GetStorage.init();
  }

  // ---------- First Time ----------
  bool isFirstTime() {
    return _box.read(_firstTimeKey) ?? true;
  }

  void setNotFirstTime() {
    _box.write(_firstTimeKey, false);
  }

  GetStorage get box => _box;
}
