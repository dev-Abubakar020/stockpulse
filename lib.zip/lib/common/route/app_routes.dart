abstract class Routes {
  ///Links
  static const onboarding = '/onboarding';
  static const login = '/login';
  static const register = '/register';
  static const forgotPassword = '/forgotPassword';
  static const resetPassword = '/resetPassword';
  static const phoneDetails = '/phoneDetails';
  static const otpVerification = '/otpVerification';

  static const dashboard = '/dashboard';
  static const home = '/homeView';
}
