import 'package:stockpulse/common/bindings/loginBinding.dart';
import 'package:stockpulse/common/bindings/signUpBinding.dart';
import 'package:stockpulse/views/login.dart';
import 'package:stockpulse/views/onboarding.dart';
import 'package:stockpulse/views/signup.dart';
import 'package:stockpulse/views/forgotPassword.dart';
import 'package:stockpulse/views/otpverification.dart';
import 'package:stockpulse/views/phonedetailScreen.dart';

import 'app_routes.dart';

import 'package:get/get.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';

class AppPages {
  static final pages = [
    ///Links
    ///Starting screens
    // GetPage(
    //   name: Routes.splash,
    //   page: () => const SplashView(),
    //   binding: SplashBinding(),
    // ),
    GetPage(name: Routes.onboarding, page: () => const OnboardingScreen()),
    GetPage(
      name: Routes.login,
      page: () => const LoginScreen(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: Routes.register,
      page: () => const SignupView(),
      binding: SignupBinding(),
    ),
    GetPage(
      name: Routes.forgotPassword,
      page: () => const ForgotPasswordScreen(),
    ),
    GetPage(name: Routes.phoneDetails, page: () => const PhoneDetailScreen()),
    GetPage(
      name: Routes.otpVerification,
      page: () => const OtpVerificationScreen(),
    ),
    // GetPage(name: Routes.onboarding, page: () => const OnboardingScreen()),
  ];
}
